  function showPage(pageId){
  const sections=
  document.querySelectorAll('.page-section');
  sections.forEach(section=>{
  section.classList.remove('active');
  });
  document.getElementById(pageId).classList.add('active');
  const links=
  document.getElementById('navlinks');
  if(pageId==='login'|| pageId==='signupPage'){
  links.style.display='none';
  }
  else{ links.style.display='flex';
  }
  if(pageId==='cartPage'){ displayCart(); }
  if(pageId==='paymentSuccess'){ generateOrderNumber(); }
  }
showPage('login');
let cart = [];

const productImages = {
  'Function of Beauty:Pink Deep Hydration': 'images/001.jpg',
  'Function of Beauty:Purple Deep Hydration': 'images/002.jpg',
  'Function of Beauty:Blue Deep Hydration': 'images/003.jpg',
  "L'Oreal Paris:Oil Hair Serum": 'images/004.jpg',
  'Oil Midnight Serum': 'images/005.jpg',
  'TRESemmé:Hair Serum': 'images/006.jpg',
  'Adore:WILD CHERRY': 'images/007.jpg',
  'Adore:Sienna Brown': 'images/008.jpg',
  'Adore:Rich Eggplant': 'images/009.jpg',
  'Fino::Hair Serum Mask': 'images/010.jpg',
  "L'Oreal Paris:Hair Mask": 'images/011.jpg',
  'Pantene:Hair Mask': 'images/012.jpg'
};

function addToCart(productName, price) {
  const existing = cart.find(item => item.name === productName);
  if (existing) {
    existing.qty = (existing.qty || 1) + 1;
  } else {
    cart.push({ name: productName, price: price, qty: 1, image: productImages[productName] || '' });
  }
  alert(productName + " Added successfully to the cart ✅!");
  displayCart();
}

function displayCart() {
  const cartItemDiv = document.getElementById('cart-items');
  const emptyDiv = document.getElementById('cart-empty');
  const summary = document.getElementById('cart-summary');
  const totalEl = document.getElementById('cart-total-amount');
  if (!cartItemDiv) return;

  cartItemDiv.innerHTML = "";
  let total = 0;

  if (cart.length === 0) {
    if (emptyDiv) emptyDiv.style.display = 'block';
    if (summary) summary.style.display = 'none';
    return;
  }

  if (emptyDiv) emptyDiv.style.display = 'none';
  if (summary) summary.style.display = 'block';

  cart.forEach((item, index) => {
    const qty = item.qty || 1;
    total += item.price * qty;
    const img = item.image || productImages[item.name] || '';
    cartItemDiv.innerHTML += `
      <div class="cart-item">
        <div class="cart-item-img">
          ${img ? `<img src="${img}" alt="${item.name}">` : ''}
        </div>
        <div class="cart-item-info">
          <h3 class="cart-item-name">${item.name}</h3>
          <p class="cart-item-price">${item.price}SR</p>
        </div>
        <div class="qty-control">
          <button class="qty-btn" onclick="changeQty(${index}, 1)">+</button>
          <span class="qty-value">${qty}</span>
          <button class="qty-btn" onclick="changeQty(${index}, -1)">−</button>
        </div>
        <button class="remove-link" onclick="removeFromCart(${index})">Remove</button>
      </div>`;
  });

  if (totalEl) totalEl.textContent = total + "SR";
}

function changeQty(index, delta) {
  if (!cart[index]) return;
  cart[index].qty = (cart[index].qty || 1) + delta;
  if (cart[index].qty <= 0) {
    cart.splice(index, 1);
  }
  displayCart();
}

function removeFromCart(index) {
  cart.splice(index, 1);
  displayCart();
}

function checkout() {
  if (cart.length === 0) {
    alert("Your cart is empty. Add a product before completing the order.");
    return;
  }
  cart = [];
  displayCart();
  showPage('paymentSuccess');
}

function completeOrder() {
  checkout();
}

function generateOrderNumber() {
  const num = "#" + Math.floor(10000000 + Math.random() * 90000000);
  const el = document.getElementById('orderNumber');
  if (el) el.textContent = num;
}
